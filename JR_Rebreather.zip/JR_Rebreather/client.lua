ESX = exports['es_extended']:getSharedObject()

local rebreatherOn = false
local originalClothes = {}
local playerPed = nil
local oxygenThread = false
local oxygenLeft = Config.MaxOxygen
local bubbles = {}

-- Initialize bubbles for screen space (0..1)
for i = 1, 10 do
    table.insert(bubbles, {
        x = math.random(), -- 0..1 normalized screen x
        y = math.random(), -- 0..1 normalized screen y
        speed = math.random(3, 8)/1000, -- movement speed
        radius = math.random(3, 5)/100 -- small radius
    })
end

RegisterNetEvent('jr_rebreather:toggle', function()
    playerPed = PlayerPedId()
    --print("^3[DEBUG] Player triggered rebreather toggle^0")
    --print("^3[DEBUG] Current rebreather state:^0", rebreatherOn)

    if rebreatherOn then
        RemoveRebreather()
    else
        EquipRebreather()
    end
end)

-- EQUIP REBREATHER
function EquipRebreather()
    --print("^3[DEBUG] Equipping rebreather...^0")

    if Config.ClothingSystem == "illenium" then
        local pedAppearance = exports['illenium-appearance']:getPedAppearance(playerPed)
        originalClothes = pedAppearance.components[Config.RebreatherClothing.component]
        --print("^3[DEBUG] Saved original illenium component:^0", json.encode(originalClothes))
    elseif Config.ClothingSystem == "skinchanger" then
        TriggerEvent('skinchanger:getSkin', function(skin)
            originalClothes = skin
            --print("^3[DEBUG] Saved original skinchanger clothes:^0", json.encode(originalClothes))
        end)
    end

    if Config.ClothingSystem == "illenium" then
        exports['illenium-appearance']:setPedComponent(playerPed, Config.RebreatherClothing.component, Config.RebreatherClothing.drawable, Config.RebreatherClothing.texture)
        --print("^2[DEBUG] Applied rebreather mask (illenium)^0")
    elseif Config.ClothingSystem == "skinchanger" then
        local newClothes = originalClothes or {}
        newClothes['mask_1'] = Config.RebreatherClothing.drawable
        newClothes['mask_2'] = Config.RebreatherClothing.texture
        TriggerEvent('skinchanger:loadClothes', originalClothes, newClothes)
        --print("^2[DEBUG] Applied rebreather mask (skinchanger)^0")
    end

    lib.notify({
        title = 'Rebreather Equipped',
        description = 'You put on your rebreather. Oxygen will only be tracked underwater.',
        type = 'success'
    })

    rebreatherOn = true
    oxygenLeft = Config.MaxOxygen
    StartOxygenThread()
    StartBubbleHUDThread()
end

-- REMOVE REBREATHER
function RemoveRebreather()
    --print("^3[DEBUG] Removing rebreather...^0")

    -- Immediately hide UI before anything else
    lib.hideTextUI()

    if Config.ClothingSystem == "illenium" then
        exports['illenium-appearance']:setPedComponent(playerPed, Config.RebreatherClothing.component, originalClothes.drawable or 0, originalClothes.texture or 0)
        --print("^2[DEBUG] Restored illenium appearance^0")
    elseif Config.ClothingSystem == "skinchanger" then
        if originalClothes and next(originalClothes) ~= nil then
            ExecuteCommand("reloadskin")
            --print("^2[DEBUG] Restored original skinchanger clothes^0")
        else
            local emptyClothes = {['mask_1']=0, ['mask_2']=0}
            TriggerEvent('skinchanger:loadClothes', emptyClothes, emptyClothes)
            --print("^1[DEBUG] No original clothes saved, reset mask to none^0")
        end
    end

    -- Reset player proofs and stop threads
    SetEntityProofs(playerPed, false,false,false,false,false,false,false,false)
    oxygenThread = false
    rebreatherOn = false

    -- Notify player
    lib.notify({
        title = 'Rebreather Removed',
        description = 'You took off your rebreather.',
        type = 'error'
    })

    --print("^2[DEBUG] Rebreather successfully removed^0")
end

-- OXYGEN THREAD
function StartOxygenThread()
    if oxygenThread then return end
    oxygenThread = true
    --print("^3[DEBUG] Starting oxygen management thread^0")

    CreateThread(function()
        while oxygenThread do
            Wait(Config.OxygenUpdateRate)

            if rebreatherOn and IsPedSwimmingUnderWater(playerPed) then
                SetPedMaxTimeUnderwater(playerPed, 50.0)
                SetEntityProofs(playerPed,false,false,false,false,true,false,false,false)

                oxygenLeft = oxygenLeft - 1
               -- print("^3[DEBUG] Oxygen remaining:^0", oxygenLeft)

                -- Show TextUI only if oxygen > 0
                if oxygenLeft > 0 then
                    local pct = oxygenLeft / Config.MaxOxygen
                    local color = {r=72,g=187,b=120}
                    if pct <= 0.5 then color = {r=255,g=200,b=0} end
                    if pct <= 0.25 then color = {r=255,g=0,b=0} end
                    local alpha = 180 + math.floor(math.sin(GetGameTimer()/300)*50)

                    lib.showTextUI(string.format('OXYGEN: %ds', oxygenLeft), {
                        position = "top-center",
                        icon = nil,
                        style = {
                            borderRadius = 12,
                            backgroundColor = string.format('rgba(%d,%d,%d,%d)', color.r,color.g,color.b,alpha),
                            color = 'white',
                            padding = '6px 12px',
                            fontSize = '22px',
                            fontWeight = 'bold',
                            boxShadow = '0 0 12px rgba(0,0,0,0.6)',
                            textAlign = 'center'
                        }
                    })
                else
                    -- Oxygen depleted → hide TextUI immediately
                    lib.hideTextUI()
                    lib.notify({
                        title = 'Rebreather Empty',
                        description = 'Your oxygen tank is depleted!',
                        type = 'warning'
                    })
                    local xPlayer = ESX.GetPlayerData()
                    TriggerServerEvent('jr_rebreather:removeItem')
                    RemoveRebreather() -- remove mask
                end
            else
                -- Hide UI when surfaced
                lib.hideTextUI()
            end
        end
    end)
end

-- BUBBLE HUD THREAD
function StartBubbleHUDThread()
    CreateThread(function()
        while true do
            Wait(0)

            -- If rebreather is off, hide UI and skip
            if not rebreatherOn then
                lib.hideTextUI()
                Wait(500) -- prevent tight loop
            else
                if IsPedSwimmingUnderWater(playerPed) then
                    for i,bubble in ipairs(bubbles) do
                        bubble.y = bubble.y - bubble.speed
                        if bubble.y < 0 then
                            bubble.y = 1
                            bubble.x = math.random()
                        end

                        local circleSegments = 8
                        for j=0,circleSegments-1 do
                            local angle = (j / circleSegments) * math.pi*2
                            local dx = math.cos(angle) * bubble.radius
                            local dy = math.sin(angle) * bubble.radius
                            DrawRect(bubble.x+dx, bubble.y+dy, 0.003, 0.003, 135,206,250,150)
                        end
                    end

                    -- Oxygen text only if > 0
                    if oxygenLeft > 0 then
                        local pct = oxygenLeft / Config.MaxOxygen
                        local color = {r=72,g=187,b=120}
                        if pct <= 0.5 then color = {r=255,g=200,b=0} end
                        if pct <= 0.25 then color = {r=255,g=0,b=0} end
                        local alpha = 180 + math.floor(math.sin(GetGameTimer()/300)*50)

                        lib.showTextUI(string.format('OXYGEN: %ds', oxygenLeft), {
                            position = "top-center",
                            icon = nil,
                            style = {
                                borderRadius = 12,
                                backgroundColor = string.format('rgba(%d,%d,%d,%d)', color.r,color.g,color.b,alpha),
                                color = 'white',
                                padding = '6px 12px',
                                fontSize = '22px',
                                fontWeight = 'bold',
                                boxShadow = '0 0 12px rgba(0,0,0,0.6)',
                                textAlign = 'center'
                            }
                        })
                    else
                        lib.hideTextUI() -- definitive hide
                    end
                else
                    lib.hideTextUI()
                end
            end
        end
    end)
end