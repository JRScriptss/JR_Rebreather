fx_version 'cerulean'
game 'gta5'

author 'JRScripts'
description 'JR Rebreather System'
version '1.0.0'

shared_script 'config.lua'

--shared_script '@ox_lib/init.lua'

client_scripts {
    'client.lua',
    '@ox_lib/init.lua'
}

server_scripts {
    '@es_extended/imports.lua',
    'server.lua'
}
dependencies {
    'es_extended',       -- ES_Extended framework
    'ox_lib',            -- OX Lib for context menus and utilities
}