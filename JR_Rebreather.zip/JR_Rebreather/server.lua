ESX = exports['es_extended']:getSharedObject()

-- Register usable item
ESX.RegisterUsableItem(Config.RebreatherItem, function(source)
    TriggerClientEvent('jr_rebreather:toggle', source)
end)

RegisterNetEvent('jr_rebreather:removeItem', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        xPlayer.removeInventoryItem('rebreather', 1)
        print("^2[DEBUG] Rebreather removed from inventory^0")
    end
end)