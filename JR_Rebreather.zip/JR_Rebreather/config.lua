Config = {}

-- Clothing system: "illenium" or "skinchanger"
Config.ClothingSystem = "skinchanger"

-- Rebreather item name
Config.RebreatherItem = "rebreather"

-- Rebreather clothing setup
Config.RebreatherClothing = {
    component = 1, -- Mask slot for illenium-appearance
    drawable = 36, -- Mask model ID
    texture = 0,   -- Texture variation
}

-- Oxygen tank settings
Config.MaxOxygen = 50 -- in seconds max is 50
Config.OxygenUpdateRate = 1000 -- how often oxygen decreases (ms)
